export interface ResponseDisplayProps {
  response: string;
}
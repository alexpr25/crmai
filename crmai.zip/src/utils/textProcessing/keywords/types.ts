export interface KeywordExtractionOptions {
  minLength?: number;
  excludeNumbers?: boolean;
  caseSensitive?: boolean;
}
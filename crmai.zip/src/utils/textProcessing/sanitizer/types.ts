export interface SanitizerOptions {
  trimWhitespace?: boolean;
  normalizeSpaces?: boolean;
  removePunctuation?: boolean;
}